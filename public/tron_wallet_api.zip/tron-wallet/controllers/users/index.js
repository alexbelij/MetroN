module.exports = {
    walletController: require('./wallet')
}