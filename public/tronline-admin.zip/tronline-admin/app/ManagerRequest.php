<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ManagerRequest extends Model
{
    //
}
