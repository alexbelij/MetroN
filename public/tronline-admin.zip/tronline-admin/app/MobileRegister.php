<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MobileRegister extends Model
{
    //
}
