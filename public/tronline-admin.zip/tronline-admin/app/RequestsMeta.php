<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RequestsMeta extends Model
{
    protected $table = 'requests_meta';
}
