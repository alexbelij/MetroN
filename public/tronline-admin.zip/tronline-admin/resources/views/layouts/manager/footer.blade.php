<footer class="main-footer">
    <div class="pull-right hidden-xs">
    <b>Version</b> 2.3.3
    </div>
    <strong>Copyright &copy; 2014-2015 <a href="#">Smart Car</a>.</strong> All rights
    reserved.
</footer>
